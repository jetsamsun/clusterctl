<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetDetail extends Model
{
    //
    public $table='asset_detail';//这样寻找的就是没s的表
}
