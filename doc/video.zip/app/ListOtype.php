<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListOtype extends Model
{
    //
    public $table='list_otype';//这样寻找的就是没s的表
}
