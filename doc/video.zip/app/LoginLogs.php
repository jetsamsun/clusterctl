<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoginLogs extends Model
{
    //
    public $table='login_logs';//这样寻找的就是没s的表
}
