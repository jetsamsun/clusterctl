<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScreenOtype extends Model
{
    //
    public $table='screen_otype';//这样寻找的就是没s的表
}
