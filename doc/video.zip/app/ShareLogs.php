<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShareLogs extends Model
{
    //
    public $table='share_logs';//这样寻找的就是没s的表
}
