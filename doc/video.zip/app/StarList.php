<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StarList extends Model
{
    //
    public $table='star_list';//这样寻找的就是没s的表
}
