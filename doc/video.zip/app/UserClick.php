<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserClick extends Model
{
    //
    public $table='user_click';//这样寻找的就是没s的表
}
