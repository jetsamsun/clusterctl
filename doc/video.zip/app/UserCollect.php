<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserCollect extends Model
{
    //
    public $table='user_collect';//这样寻找的就是没s的表
}
