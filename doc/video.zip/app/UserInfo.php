<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserInfo extends Model
{
    //
    public $table='user_info';//这样寻找的就是没s的表
}
