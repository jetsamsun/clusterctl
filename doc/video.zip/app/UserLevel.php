<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserLevel extends Model
{
    //
    public $table='user_level';//这样寻找的就是没s的表
}
