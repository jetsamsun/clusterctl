<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserWithdraw extends Model
{
    //
    public $table='user_withdraw';//这样寻找的就是没s的表
}
