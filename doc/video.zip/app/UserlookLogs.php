<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserlookLogs extends Model
{
    //
    public $table='userlook_logs';//这样寻找的就是没s的表
}
