<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Version extends Model
{
    //
    public $table='version';//这样寻找的就是没s的表
}
