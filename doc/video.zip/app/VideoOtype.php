<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoOtype extends Model
{
    //
    public $table='video_otype';//这样寻找的就是没s的表
}
