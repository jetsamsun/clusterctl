<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoTrouble extends Model
{
    //
    public $table='video_trouble';//这样寻找的就是没s的表
}
