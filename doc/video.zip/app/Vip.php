<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vip extends Model
{
    //
    public $table='vip';//这样寻找的就是没s的表
}
