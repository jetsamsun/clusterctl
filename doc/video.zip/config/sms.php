<?php
/**
 * @desc 短信平台配置信息
 * @date 2019-04-16
 * @user chenglong
 */
return [
    '253' => array(
        'name'=>'N5232162',
        'password'=>'5NqXCTu3H162d6',
        'msg'=>'【小乐文化】',
        'nameItn'=>'I5177077',
        'passwordItn'=>'Yl4EPpDWVA5add',
    ),
];
?>