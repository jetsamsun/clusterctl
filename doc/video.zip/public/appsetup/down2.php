<script>
location.href='itms-services://?action=download-manifest&url=https://web2.hotbox99.tv/app/test.plist';
window.close();
</script>
