<html>
<head>
<title>iOS青瓜安装升级</title>
<meta http-equiv="Content-Type" content="text/HTML; charset=utf-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<script type="text/javascript">
function doLocation(url)
{
 var a = document.createElement("a");
 if(!a.click) 
 {
 window.location = url;
 return;
 }
 a.setAttribute("href", url);
 a.style.display = "none";
 document.body.appendChild(a);
 a.click();
}
</script>
</head>
<body>
</br>
</br>
<center>请点击确认下载升级</center>
<script type="text/javascript">
doLocation('itms-services://?action=download-manifest&url=https://down.qg5.live/app/test.plist');
</script>
</body>
</html>
