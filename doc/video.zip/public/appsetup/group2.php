<?php  
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
//header("location:https://pt.im/joinchat/00141f45e41a448dc2a4d6d15391136dc9a");
header("location:https://web.pt.im/qgtv99?v=2");
// header("location:pt://resolve?domain=qgtv99");
?>
