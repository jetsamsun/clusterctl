<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <title>通知</title>
    <meta name="format-detection" content="telephone=no" />
    <meta name="description" content="青瓜TV cctv4.me www.cctv4.me 青瓜视频 青瓜影视">
    <meta name="keywords" content="青瓜TV cctv4.me www.cctv4.me 青瓜视频 青瓜影视">
    <script src="./js/clipboard.min.js"></script>
    <link rel="stylesheet" type="text/css" href="" />
</head>

<body style="background-color:#ccc;">

<div class="" style="font-size:16px;text-align:center;">
</br>
</br>
</br>
</br>
   <div style="color:red;">充值系统维护中</div>
   </br>
   <div style="color:red;">近期恢复，给您造成不便敬请谅解</div>
   </br>
   </br>
   </br>
   <div>加入”土豆“交流群</br>获取最新动态</div>
   </br>
   <a href="group.php?v=1"><img src="./images/btn-potato.png?v=1" width="180"/></a>   
            </br>
            </br>            
</div>

</body>

</html>
